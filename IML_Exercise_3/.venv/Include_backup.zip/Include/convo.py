import numpy as np
from PIL import Image
import math


def make_kernel(ksize, sigma):
    """
    Create a Gaussian kernel with specified size and sigma.
    """
    kernel = np.zeros((ksize, ksize))
    center = ksize // 2
    sum_val = 0
    for i in range(ksize):
        for j in range(ksize):
            x = i - center
            y = j - center
            kernel[i, j] = (1 / (2 * np.pi * sigma ** 2)) * np.exp(-(x ** 2 + y ** 2) / (2 * sigma ** 2))
            sum_val += kernel[i, j]
    # Normalize the kernel
    kernel /= sum_val
    return kernel


def slow_convolve(arr, k):
    """
    Apply convolution with the specified kernel and zero padding.
    """
    arr_height, arr_width = arr.shape
    k_height, k_width = k.shape
    pad_height = k_height // 2
    pad_width = k_width // 2

    # Flip the kernel horizontally and vertically
    k_flipped = np.flip(k)

    # Pad the input array
    padded_arr = np.pad(arr, ((pad_height, pad_height), (pad_width, pad_width)), mode='constant', constant_values=0)

    # Prepare the output array
    convolved_arr = np.zeros_like(arr)

    # Perform convolution
    for i in range(arr_height):
        for j in range(arr_width):
            # Extract the region of interest
            region = padded_arr[i:i + k_height, j:j + k_width]
            # Compute the convolution sum
            convolved_arr[i, j] = np.sum(region * k_flipped)

    return convolved_arr


if __name__ == '__main__':
    # Create the Gaussian kernel
    k = make_kernel(ksize=3, sigma=1)  # todo: find better parameters if needed

    # Choose an image
    im = np.array(Image.open('input1.jpg').convert('L'))  # convert to grayscale

    # Blur the image using convolution
    blurred = slow_convolve(im, k)

    # Create the unsharp mask
    unsharp_mask = im - blurred

    # Sharpen the image by adding the unsharp mask to the original
    sharpened = im + unsharp_mask

    # Clip values to the range [0, 255] and convert to uint8
    sharpened = np.clip(sharpened, 0, 255).astype(np.uint8)

    # Save the result
    result_image = Image.fromarray(sharpened)
    result_image.save('sharpened_output.jpg')

    # Optionally, display the result
    result_image.show()
